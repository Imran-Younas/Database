﻿namespace LinkedInClone
{


    partial class LinkedInDataSet
    {
    }
}
