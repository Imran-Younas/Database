﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Windows.Forms.VisualStyles;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace LinkedInClone
{
    public partial class Homepage : Form
    {
        private bool isCollapsed;
        private bool isExpanded;
        private DataTable dataTable;
        public SqlConnection cn = new SqlConnection();
        public SqlCommand cmd = new SqlCommand();
        private DBConnection dbcon = new DBConnection();
        public SqlDataReader dr;
        public Homepage()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            this.KeyPreview = true;
        }

        public int current_user_id()
        {
            bool found = false;
            int userid = -1;
            cn.Open();
            string Query = "Select * From Users " +
                           "Where Status = 1 ;";
            cmd = new SqlCommand(Query , cn);
            dr = cmd.ExecuteReader();
            dr.Read();
            if (dr.HasRows)
            {
                found = true;
               userid = Int32.Parse(dr["UserID"].ToString());
               cn.Close();
               dr.Close();
            }
            else
            {
                return userid;
            }
            return userid;
        }
        /*public DataTable Comment_DataLoad()
        {
            cn.Close();
            cn.Open();
            string query = "SELECT CmntTxt FROM COMMENTS " +
                           "WHERE Post_id = @postid ;";
            cmd = new SqlCommand(query, cn);
            cmd.Parameters.AddWithValue("@post_id",text_Postid1.Text);
            cmd.ExecuteNonQuery();
            dataTable = new DataTable();
            adapter.Fill(dataTable);
            return dataTable;
        }*/
        private void button_Extra1_Click(object sender, EventArgs e)
        {
            timer2.Start();
            timer1.Start();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button_Logout1_Click(object sender, EventArgs e)
        {
            cn.Open();
            cmd = new SqlCommand("Update Users " +
                                 "SET Status = 0 " +
                                 "WHERE Status = 1 ;", cn);
            cmd.ExecuteNonQuery();
            cn.Close();
            this.Hide();
            Login log = new Login();
            log.ShowDialog();
            this.Hide();
        }

        private void button_Profile1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (isCollapsed)
            {
                panel_DropDown1.Height -= 10;
                if (panel_DropDown1.Size == panel_DropDown1.MinimumSize)
                {
                    timer1.Stop();
                    isCollapsed=false;
                }
            }
            else
            {
                panel_DropDown1.Height += 10;
                panel1.Height += 500;
                if (panel_DropDown1.Size == panel_DropDown1.MaximumSize)
                {
                    timer1.Stop();
                    isCollapsed = true;
                }
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }


        private void timer2_Tick(object sender, EventArgs e)
        {
            if (isExpanded)
            {
                panel1_Home.Height -= 10;
                if (panel1_Home.Size == panel1_Home.MinimumSize)
                {
                    timer2.Stop();
                    isExpanded = false;
                }
            }
            else
            {
                panel1_Home.Height += 10;
                if (panel1_Home.Size == panel1_Home.MaximumSize)
                {
                    timer2.Stop();
                    isExpanded = true;
                }
            }
        }

        private void panel1_Home_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button_Home1_Click_1(object sender, EventArgs e)
        {

        }

        private void button_MyNetwork1_Click_1(object sender, EventArgs e)
        {

        }

        private void button_Jobs1_Click_1(object sender, EventArgs e)
        {

        }

        private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void flowLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void Homepage_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'linkedInDataSet4.Post' table. You can move, or remove it, as needed.
            this.postTableAdapter2.Fill(this.linkedInDataSet4.Post);
        }

        

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            string query = "SELECT * FROM Post";
            SqlDataAdapter adapter = new SqlDataAdapter(query, cn);
            DataTable dataTable = new DataTable();
            MessageBox.Show("Data retrieved: " + dataTable.Rows.Count + " rows.");
            adapter.Fill(dataTable);
            
            // Bind the DataTable to the DataGridView
            dataGridView1.DataSource = dataTable;

            if (e.RowIndex>=0)
            {

            }
            /*if (dataGridView1.SelectedRows.Count > 0)
            {
                text_Postid1.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                text_Posttitle1.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                text_PostContent1.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            }*/
            /*try
            {
                bool found;
                string content = "";
                int likes = 0;
                int user_id = 0;
                int post_id = 0;
                cn.Open();
                cmd = new SqlCommand("SELECT * FROM Users;", cn);
                dr = cmd.ExecuteReader();
                dr.Read();
                if (dr.HasRows)
                {
                    found = true;
                    post_id = Int32.Parse(dr["Post_id"].ToString());
                    content = dr["Post_Content"].ToString();
                    user_id = Int32.Parse(dr["UserID"].ToString());
                    likes= Int32.Parse(dr["NoOfLikes"].ToString());

                }
                else
                {
                    found = false;
                    dr.Close();
                    cn.Close();
                }
                if (found == true)
                {
                    // Login log = new Login();

                    dataGridView1.Columns();
                    dr.Close();
                    cn.Close();
                }
                else
                {
                    MessageBox.Show("Invalid Username or Password!", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }*/
        }

        private void flowLayoutPanel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (text_Postid1.Text != "" && text_Postid1.Text != "Post Id")
            {
                cn.Open();
                string Query2 = "SELECT * FROM POST " +
                               "WHERE Post_id = @postid ; ";
                cmd = new SqlCommand(Query2 , cn);
                cmd.Parameters.AddWithValue("@postid", text_Postid1.Text);
                dr = cmd.ExecuteReader();
                dr.Read();
                if (dr.HasRows)
                {
                    text_Posttitle1.Text = dr["Post_Title"].ToString();
                    text_PostContent1.Text = dr["Post_Content"].ToString();
                }
                else
                {
                    MessageBox.Show("Post does not exist. Please enter valid id.",
                        "Invalid post", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cn.Close();
                    dr.Close();
                }
                cn.Close();
                dr.Close();

            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint_2(object sender, PaintEventArgs e)
        {

        }

        private void text_Title2_TextChanged(object sender, EventArgs e)
        {

        }

        private void text_Content2_TextChanged(object sender, EventArgs e)
        {

        }

        private void text_Posttitle1_TextChanged(object sender, EventArgs e)
        {

        }

        private void text_PostContent1_TextChanged(object sender, EventArgs e)
        {

        }

        private void text_Comment1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_Comment1_Click(object sender, EventArgs e)
        {
            try
            {
                if (text_Postid1.Text == "")
                {
                    MessageBox.Show("Post id cannot be empty. Please enter a post id.",
                        "Empty post id", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (text_Comment1.Text == "")
                {
                    MessageBox.Show("Comment cannot be empty. Please enter any sentence or word!!!",
                        "Empty Comment", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int userid = current_user_id();
                if (userid == -1)
                {
                    MessageBox.Show("Warning no active users found." , 
                        "Invalid Session" , MessageBoxButtons.OK , 
                        MessageBoxIcon.Warning);
                    return;
                }
                DateTime dt = DateTime.Now;
                cn.Open();
                string Query = "Insert Into Comments (Post_id , UserID , CmntTxt) " +
                               "VALUES (@post_id , @userid , @CmntText) ;" ;
                cmd = new SqlCommand(Query, cn);
                cmd.Parameters.AddWithValue("@post_id", text_Postid1.Text);
                cmd.Parameters.AddWithValue("@userid", userid.ToString());
                cmd.Parameters.AddWithValue("@CmntText",text_Comment1.Text);
                //cmd.Parameters.AddWithValue("@timestamp" , dt.ToString());
                cmd.ExecuteNonQuery();
                /*SqlDataAdapter adapter = new SqlDataAdapter(Query, cn);
                DataTable dtbl = new DataTable();
                adapter.Fill(dtbl);

                dataGridView2.AutoGenerateColumns = false;
                dataGridView2.DataSource = dtbl;*/
                cn.Close();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                throw;
            }
        }

        private void button_ShowComments1_Click(object sender, EventArgs e)
        {
            try
            {
                cn.Open();
                if (text_Postid1.Text == "")
                {
                    MessageBox.Show("Post id cannot be empty. Please enter a post id.",
                        "Empty post id", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                string Query = "SELECT * FROM Comments " +
                               "WHERE Post_id = " + text_Postid1.Text;
                SqlDataAdapter adapter = new SqlDataAdapter(Query, cn);
                DataTable dtbl = new DataTable();
                adapter.Fill(dtbl);

                dataGridView2.AutoGenerateColumns = false;
                dataGridView2.DataSource = dtbl;
                cn.Close();
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                throw;
            }
        }

        private void button_Addpost1_Click(object sender, EventArgs e)
        {

        }

        private void txt_Search1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_Search1_Click(object sender, EventArgs e)
        {

        }
    }
}
